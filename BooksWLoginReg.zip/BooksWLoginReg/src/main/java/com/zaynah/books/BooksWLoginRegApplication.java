package com.zaynah.books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksWLoginRegApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksWLoginRegApplication.class, args);
	}

}
