package com.zaynah.daikichii;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichiiPathVariablesApplicationTests {

	@Test
	void contextLoads() {
	}

}
